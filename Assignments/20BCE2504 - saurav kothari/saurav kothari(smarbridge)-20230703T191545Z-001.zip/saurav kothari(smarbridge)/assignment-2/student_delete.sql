delete from student where studid='292935';
alter table student drop column address;
select * from student;