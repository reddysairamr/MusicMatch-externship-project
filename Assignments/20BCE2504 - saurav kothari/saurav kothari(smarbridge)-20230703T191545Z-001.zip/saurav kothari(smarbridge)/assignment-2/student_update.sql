update student set address='vrindavan colony gola road patna' where studid=292939;
update student set address='lokhandwal , mumbai' where studid=292937;
update student set address='kota rajasthan' where studid=292935;
select * from student